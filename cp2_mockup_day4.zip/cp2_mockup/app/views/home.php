<?php require_once "../partials/template.php" ?>
<?php function get_page_content() { ?>
<div class="container-fluid" id = "hero-banner">
	<div class="jumbotron text-center text-white">
		<h1>Bored Games</h1>
		<p>You'll never get bored playing games.</p>
	</div>
</div>
<?php } ?>