<?php 
	header("Location: ./views/home.php");
?>