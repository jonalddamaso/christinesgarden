<footer id="main-footer" class="bg-dark">
	<p class="text-center py-4 text-white my-0">
		Copyright &copy; 2018 Bored games
	</p>
</footer>
<script type="text/javascript" src="../assets/js/script.js"></script>